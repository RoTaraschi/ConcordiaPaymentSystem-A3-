import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JSplitPane;


public class MainFrame extends JFrame implements ActionListener, MouseListener{
	
//---------------Attributes

	private MenuPanel currentMainMenu;
	private GamePanel newGame;
	private InfoPanel infoPanel;
	private BottomPanel bottomPanel;
	private Player player;
	private String newName;
	
//---------------Constructors
	
	public MainFrame()
	{
	    this.setTitle("Enhanced Minesweeper");
	    
	    //initialize all attributes
		currentMainMenu = new MenuPanel();
		newGame = new GamePanel();		
		infoPanel = new InfoPanel(newName, 0, 0);
		bottomPanel = new BottomPanel();
		player = new Player();
		
		//Gets name before each game.
		setupFrame();
	    
		
		newName = JOptionPane.showInputDialog(this,"Enter your name","New Game",JOptionPane.WARNING_MESSAGE);
	    
		player.setName(newName);
		infoPanel = new InfoPanel(newName, 0, 3);
		setupFrame();

		currentMainMenu.getNewGameButton().addActionListener(this);		//THE MAGIC!! Use methods!!
		currentMainMenu.getAboutButton().addActionListener(this);
		currentMainMenu.getQuitButton().addActionListener(this);
		
		//adds listener for all game buttons.
		for (int x = 0; x < newGame.getButtonsLength(); x++) 
		{
			for (int y = 0; y < newGame.getButtonsLength0(); y++) 
			{
				newGame.getPlayerMove(x, y).addMouseListener(this);
				newGame.getPlayerMove(x,y).addActionListener(this);
			}
		}
	}
	
//---------------Methods
	
	
	public JButton getnewGameButton()
	{
		return this.currentMainMenu.newGameButton;
	}
	
	public void setupFrame()
	{
		//BorderLayout Manager seemed fairly easy so I went with it.
		getContentPane().setLayout(new BorderLayout());
		this.setSize(800,675);//
		
		
		//this adds each panel to the main frame.
		getContentPane().add(infoPanel, BorderLayout.WEST);
		getContentPane().add(currentMainMenu, BorderLayout.NORTH);
		getContentPane().add(bottomPanel, BorderLayout.SOUTH);	
		getContentPane().add(newGame, BorderLayout.EAST);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
	    this.setVisible(true);
	}
	
	
	
	public void hitMine(int xx, int yy)
	{	
		//Handles player death
		if(player.getLivesLeft() == 0)
		{
			for (int x = 0; x < newGame.getButtonsLength(); x++) 
			{
				for (int y = 0; y < newGame.getButtonsLength0(); y++) 
				{
					if(newGame.getPlayerMove(x, y).isEnabled())
					{
						if(newGame.getPlayerGrid(x, y).getMines() ==1)
						{
							newGame.getPlayerMove(x, y).setIcon(new ImageIcon("test3.png"));
						}
						if(newGame.getPlayerGrid(x, y).getMines() ==2)
						{
							newGame.getPlayerMove(x, y).setIcon(new ImageIcon("test2.png"));
						}
						newGame.getPlayerMove(x, y).setText(newGame.getPlayerGrid(x, y).getButtonPress() + "");
						newGame.getPlayerGrid(x, y).setTileCalledTrue(true);
					}
				}
			}
		}
		else
		{	//Handles player losing one life
			player.minusLife(1);
			infoPanel.updateLife(player.getLivesLeft());
			
			if(newGame.getPlayerGrid(xx, yy).getMines() ==1)
			{
			newGame.getPlayerMove(xx, yy).setIcon(new ImageIcon("test3.png"));
			}
			if(newGame.getPlayerGrid(xx, yy).getMines() ==2)
			{
			newGame.getPlayerMove(xx, yy).setIcon(new ImageIcon("test2.png"));
			}

		}
	}
	
	
//------------------------ACTION HANDLING (All actions should be handled here)

	@Override
	public void actionPerformed(ActionEvent event) 
	{
		
		//Handles gameplay
		for (int x = 0; x < newGame.getButtonsLength(); x++) 
		{
			for (int y = 0; y < newGame.getButtonsLength0(); y++) 
			{
		
				
				if(event.getSource().equals(newGame.getPlayerMove(x, y)))
				{
					//handles safe click
					if(newGame.getPlayerGrid(x, y).getMines() == 0 && newGame.getPlayerGrid(x, y).getExtraLife() == 0 && newGame.getPlayerGrid(x, y).getCalled() == false)
					{
					player.setScore(1);
					newGame.getPlayerGrid(x, y).setTileCalledTrue(true);
					newGame.getPlayerMove(x, y).setText(newGame.getPlayerGrid(x, y).getButtonPress() + ""); 
					infoPanel.updateScore(player.getScore());	
					//JOptionPane.showMessageDialog(this, "Click");
					}
					//
					
					
					//Recursion by Zero
					
					
					//
					//handles extra life click
					if(newGame.getPlayerGrid(x, y).getMines() == 0 && newGame.getPlayerGrid(x, y).getExtraLife() == 1 && newGame.getPlayerGrid(x, y).getCalled() == false)
					{
					player.setScore(1);
					player.addLife(1);
					newGame.getPlayerGrid(x, y).setTileCalledTrue(true);
					newGame.getPlayerMove(x, y).setText(newGame.getPlayerGrid(x, y).getButtonPress() + ""); 
					infoPanel.updateScore(player.getScore());	
					infoPanel.updateLife(player.getLivesLeft());
				
					//not implemented. changes big picture to 1up.
					//infoPanel.changeBigPicture("1up.png");
					
					ImageIcon oneUp = new ImageIcon("1up.png");
					JOptionPane.showMessageDialog(null, "EXTRA LIFE!\n Way to go champ.", "EXTRA LIFE!", JOptionPane.INFORMATION_MESSAGE, oneUp );
					
					}
					
					
					//handles mine click
					if (newGame.getPlayerGrid(x, y).getMines() >= 1)
					{
						hitMine(x,y);
					}
				}
			}
		}
	
		//Starts new game
		if(event.getSource().equals(currentMainMenu.getNewGameButton()))
		{
			this.dispose();
			MainFrame newMain = new MainFrame();
		}
		
		//Handles about button
		if(event.getSource().equals(currentMainMenu.getAboutButton()))
		{
			JOptionPane.showMessageDialog(this, "Mike Basdeo \n Roman T-something something");
		}
		
		//Handles about button
		if(event.getSource().equals(currentMainMenu.getQuitButton()))
		{
			this.dispose();
		}
	}

//--------------------------------------MOUSE LISTENERS	
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
