
public class Player 
{
	
//-----------------------Attributes
	
	private String name;
	private int score;
	private int livesLeft;
	

	
//----------------------Constructors
	
	public Player()
	{
		this.name = null;
		this.score = 0;
		this.livesLeft = 3;
	}
	
	
	public Player(String name)
	{
		this.name = name;
		this.score = 0;
	}
	
	
	
	
//----------------------Methods
	
	
	public void minusLife(int minusLife) 
	{
		this.livesLeft = this.livesLeft - minusLife;
	}
	
	public void addLife(int addLife)
	{
		this.livesLeft = this.livesLeft + addLife;
	}
	
	
	public int getLivesLeft()
	{
		return livesLeft;
	}
	
	public int getScore()
	{
		return score;
	}
	public void setScore(int score) 
	{
		this.score = this.score + score;
	}
	
	public void setName(String newName)
	{
		this.name = newName;
	}
	
	public String getName()
	{
		return this.name;
	}
	
	

}
