

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.TitledBorder;


class GamePanel extends JPanel implements ActionListener 
{

//--------------------------------------------------ATTRIBUTES

	JPanel panel = new JPanel();
		
	//array of buttons
	JButton[][] buttons = new JButton[10][10];
	GridTile[][] GridTiles = new GridTile[10][10];
	
	//(GUI)creates a container and we can define the layout
	Container grid = new Container();

//--------------------------------------------------CONSTRUCTOR
	
	
	public GamePanel()
	{
		// defines Container Layout to be a grid
		grid.setLayout(new GridLayout(10,10));


		//Fill Button array with JButtons
		for (int i = 0; i < buttons.length; i++) 
		{			
			for (int j = 0; j < buttons[0].length; j++) 
			{
				buttons[i][j] = new JButton();
				buttons[i][j].addActionListener(this);
				buttons[i][j].setPreferredSize(new Dimension(50,50));
				grid.add(buttons[i][j]);
			}
		}

		
		//Populate Grid Tiles with numbers
		for (int i = 0; i < 10; i++) 
		{
			for (int j = 0; j < 10; j++) 
			{
				GridTiles[i][j] = new GridTile();
			}	
		}
		
		//Create 25 random mines
		for (int i = 0; i < 25; i++) 
		{
			int choice1 = (int)(Math.random() * 10);
			int choice2 = (int)(Math.random() * 10);
			
			GridTiles[choice1][choice2].placeMine();
			
		}
		
		//Create 25 extra lives on spaces without mines.(NOT WORKING)
		for (int j = 0; j < 25; j++) 
		{
			
			int choice3 = (int)(Math.random() * 10);
			int choice4 = (int)(Math.random() * 10);
		
		
			GridTiles[choice3][choice4].placeExtraLife();
		
			
		}
		
		
		
//---------------------NEIGHBORCOUNT
		
		for (int x = 0; x < GridTiles.length; x++)
		{
			
			for (int y = 0; y < GridTiles[0].length; y++) 
			{
				
		
				int neighbourCount = 0;
				
				if(GridTiles[x][y].getMines() == 0)
				{
					
					
					if(x > 0 && y > 0 && GridTiles[x-1][y-1].getMines() == 1)			//upper left
					{
						neighbourCount++;
						
					}
					if(x > 0 && y > 0 && GridTiles[x-1][y-1].getMines() == 2)			//upper left for 2 Mines
					{
						neighbourCount +=2;
						
					}
					if( x < GridTiles.length -1 && y > 0 && GridTiles[x+1][y-1].getMines() == 1)	//upper right
					{
						neighbourCount++;
					}
					if( x < GridTiles.length -1 && y > 0 && GridTiles[x+1][y-1].getMines() == 2)	//upper right for 2 mines
					{
						neighbourCount +=2;
					}
					
					
					if(y > 0 && GridTiles[x][y-1].getMines() == 1)						//Up
					{
						neighbourCount++;
					}
					if(y > 0 && GridTiles[x][y-1].getMines() == 2)						//Up for 2 mines
					{
						neighbourCount+=2;
					}
					
																			
					if(x < GridTiles.length -1 && y < GridTiles[0].length - 1 && GridTiles[x+1][y+1].getMines() == 1)//Bottom Right
					{
						neighbourCount++;
					}
					
					if(x < GridTiles.length -1 && y < GridTiles[0].length - 1 && GridTiles[x+1][y+1].getMines() == 2)//Bottom Right for 2 Mines
					{
						neighbourCount+=2;
					}
					
					if(x > 0 && y < GridTiles[0].length - 1 && GridTiles[x-1][y+1].getMines() == 1)//Bottom Left
					{
						neighbourCount++;
					}
					if(x > 0 && y < GridTiles[0].length - 1 && GridTiles[x-1][y+1].getMines() == 2)//Bottom Left for two mines
					{
						neighbourCount+=2;
					}
					
					if(y < GridTiles[0].length - 1 && GridTiles[x][y+1].getMines() == 1) //Down
					{
						neighbourCount++;
					}
					if(y < GridTiles[0].length - 1 && GridTiles[x][y+1].getMines() == 2) //Down for two mines
					{
						neighbourCount+=2;
					}
					
					if(x > 0 && GridTiles[x-1][y].getMines() == 1) //Left
					{
						neighbourCount++;
					}
					if(x > 0 && GridTiles[x-1][y].getMines() == 2) //Left for two mines
					{
						neighbourCount+=2;
					}
					
					if(x < GridTiles.length -1 && GridTiles[x+1][y].getMines() == 1) //Right
					{
						neighbourCount++;
					}
					if(x < GridTiles.length -1 && GridTiles[x+1][y].getMines() == 2) //Right for two mines
					{
						neighbourCount+=2;
					}
					GridTiles[x][y].setCount(neighbourCount);
				}
				//Updates all neighbor numbers
			}
			
		}
	
		setupPanel();
		
	}
	
	
	
	
	public void setupPanel()
	{

		this.add(grid);
		this.setBackground(Color.GRAY);

		this.setVisible(true);
	}

	
//--------------------------METHODS
	
	
		
		public JButton getPlayerMove(int x, int y)
		{
			return buttons[x][y];
		}
		
		public GridTile getPlayerGrid(int x, int y)
		{
			return this.GridTiles[x][y];
		}
		
		public int getButtonsLength()
		{
			return buttons.length;
		}
		
		public int getButtonsLength0()
		{
			return buttons[0].length;
		}

			//All actions in MainFrame
			@Override
			public void actionPerformed(ActionEvent event)
			{
			}
	}
