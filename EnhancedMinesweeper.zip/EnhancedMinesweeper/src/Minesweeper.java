import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.util.Scanner;
import javax.swing.*;

/*Make a 2d array of objects that contains the necessary attributes.
 * 
 */

public class Minesweeper
{
	
	
	
	
	public static void main(String[] args)
	{

		
		
		
		//This opens the main Frame.
		MainFrame newMain = new MainFrame();
		
		
	

		
	}



	




}
	