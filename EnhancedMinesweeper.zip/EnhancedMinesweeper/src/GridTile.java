
class GridTile
{
	//----------------------------------------//Attributes of a single grid tile



	private boolean called;
	private int mines;
	private int count;
	private int extraLife;

	//---------------------------------------//Constructors of a single grid tile
	public GridTile()
	{
		this.mines = 0;
		this.extraLife = 0;
		this.count = 0;
		this.called = false;
	}

	//---------------------------------------//Methods of a single grid tile

	public int getMines()
	{
		return this.mines;
	}
	public void placeMine()
	{
		this.mines = this.mines + 1;;
	}
	
	public void placeExtraLife()
	{
		this.extraLife = 1;
	}
	
	public int getExtraLife()
	{
		return this.extraLife;
	}
	
	public void setCount(int newCount)
	{
		this.count = newCount;
	}
	
	public int getCount()
	{
		if(this.mines > 0)
		{
			return 9;
		}
		else
		{
			return this.count;	
		}
	}
	
	public String getButtonPress()
	{
		if(this.mines == 1)
		{
			return "m1";
		}
		else if(this.mines == 2)
		{
			return "m2";
		}
		else if(this.mines == 3)
		{
			return "m3";
		}
		else
		{
			return this.count + "";	
		}
	}
	
	

	public boolean getCalled()
	{
		return this.called;
	}
	
	//Maybe combine these two methods.
	public void setTileCalledTrue(boolean b1)
	{
		this.called = true;
	}
	public void setTileCalledFalse(boolean b1)
	{
		this.called = false;
	}

	public void resetCall()
	{
		this.called = false;
	}


}